#include "rungame.h"
#include <iostream>



Rungame::Rungame(std::size_t  kScreenWidth, std::size_t  kScreenHeight, std::size_t  kGridWidth, std::size_t kGridHeight,std::size_t  kMsPerFrame, int  i) : screen_width(kScreenWidth),
      screen_height(kScreenHeight),grid_width(kGridWidth),
      grid_height(kGridHeight), k_MsPerFrame(kMsPerFrame), _i(i){

      
}
void Rungame::startGame(){
      
  if(_i==1){
        HRenderer renderer(screen_width, screen_height, grid_width, grid_height);
        Controller controller;
        HGame game(screen_width, grid_height);
        game.Run(controller, renderer, k_MsPerFrame);
        std::cout << "Game has terminated successfully!\n";
        std::cout << "Score: " << game.GetScore() << "\n";
        std::cout << "Size: " << game.GetSize() << "\n";
  }else if(_i==2){
        Renderer renderer(screen_width, screen_height, grid_width, grid_height);
        Controller controller;
        Game game(screen_width, grid_height);
        game.Run(controller, renderer, k_MsPerFrame);
        std::cout << "Game has terminated successfully!\n";
        std::cout << "Score: " << game.GetScore() << "\n";
        std::cout << "Size: " << game.GetSize() << "\n"; 
  }
}