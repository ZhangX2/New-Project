#include "rungame.h"
#include <iostream>


int main() {
  constexpr std::size_t kFramesPerSecond{60};
  constexpr std::size_t kMsPerFrame{1000 / kFramesPerSecond};
  constexpr std::size_t kScreenWidth{640};
  constexpr std::size_t kScreenHeight{640};
  constexpr std::size_t kGridWidth{32};
  constexpr std::size_t kGridHeight{32};
  int i=1;
  
  Rungame rungame(kScreenWidth, kScreenHeight, kGridWidth, kGridHeight, kMsPerFrame, i);
  rungame.startGame();    
  return 0;
  
}