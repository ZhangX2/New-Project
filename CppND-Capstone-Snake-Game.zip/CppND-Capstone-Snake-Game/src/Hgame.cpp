#include "Hgame.h"
#include <iostream>
#include "SDL.h"


HGame::HGame(std::size_t grid_width, std::size_t grid_height)
    : snake(grid_width, grid_height),
      engine(dev()),
      random_w(0, static_cast<int>(grid_width - 1)),
      random_h(0, static_cast<int>(grid_height - 1)) {
  //Task1: Make the food project a shared pointer.
  food = std::make_shared<SDL_Point>();
  toxin = std::make_shared<SDL_Point>();
  detox = std::make_shared<SDL_Point>();
  landmine = std::make_shared<SDL_Point>();
  std::thread t1(&HGame::PlaceFood, this);
  std::thread t2(&HGame::PlaceToxin, this);
  std::thread t3(&HGame::PlaceDetox, this);
  std::thread t4(&HGame::PlaceLandmine, this);
  t1.join();
  t2.join();
  t3.join();
  t4.join();
}

void HGame::Run(Controller const &controller, HRenderer &renderer,
               std::size_t target_frame_duration) {
  Uint32 title_timestamp = SDL_GetTicks();
  Uint32 frame_start;
  Uint32 frame_end;
  Uint32 frame_duration;
  int frame_count = 0;
  bool running = true;

  while (running) {
    frame_start = SDL_GetTicks();

    // Input, Update, Render - the main game loop.
    controller.HandleInput(running, snake);
    UpdateHG();
    renderer.Render(snake, *food, *toxin, *detox, *landmine);

    frame_end = SDL_GetTicks();

    // Keep track of how long each loop through the input/update/render cycle
    // takes.
    frame_count++;
    frame_duration = frame_end - frame_start;

    // After every second, update the window title.
    if (frame_end - title_timestamp >= 1000) {
      renderer.UpdateWindowTitle(score, frame_count);
      frame_count = 0;
      title_timestamp = frame_end;
    }

    // If the time for this frame is too small (i.e. frame_duration is
    // smaller than the target ms_per_frame), delay the loop to
    // achieve the correct frame rate.
    if (frame_duration < target_frame_duration) {
      SDL_Delay(target_frame_duration - frame_duration);
    }
  }
}

void HGame::PlaceFood() {
  int x, y;
  while (true) {
    x = random_w(engine);
    y = random_h(engine);
    // Check that the location is not occupied by a snake item before placing
    // food.
    if (!snake.SnakeCell(x, y)) {
      food->x = x;
      food->y = y;
      return;
    }
  }
}

void HGame::PlaceToxin() {
  int x, y;
  while (true) {
    x = random_w(engine);
    y = random_h(engine);
    // Check that the location is not occupied by a snake item before placing
    // food.
    if (!snake.SnakeCell(x, y)&&x!=food->x&&y!=food->y) {
      toxin->x = x;
      toxin->y = y;
      return;
    }
  }
}
void HGame::PlaceDetox() {
  int x, y;
  while (true) {
    x = random_w(engine);
    y = random_h(engine);
    // Check that the location is not occupied by a snake item before placing
    // food.
    if (!snake.SnakeCell(x, y)&&x!=food->x&&y!=food->y&&x!=toxin->x&&y!=toxin->y) {
      detox->x = x;
      detox->y = y;
      return;
    }
  }
}

void HGame::PlaceLandmine() {
  int x, y;
  while (true) {
    x = random_w(engine);
    y = random_h(engine);
    // Check that the location is not occupied by a snake item before placing
    // food.
    if (!snake.SnakeCell(x, y)&&x!=food->x&&y!=food->y&&x!=toxin->x&&y!=toxin->y&&x!=detox->x&&y!=detox->y) {
      landmine->x = x;
      landmine->y = y;
      return;
    }
  }
}

void HGame::UpdateHG() {
  if (!snake.alive) return;

  snake.Update();

  int new_x = static_cast<int>(snake.head_x);
  int new_y = static_cast<int>(snake.head_y);

  // Check if there's food over here
  if (food->x == new_x && food->y == new_y) {
    score++;
    std::thread t1(&HGame::PlaceFood, this);
    t1.join();
    // Grow snake and increase speed.
    snake.GrowBody();
    snake.speed += 0.02;
  }
  if(toxin->x == new_x && toxin->y == new_y){
    std::thread t2(&HGame::PlaceToxin, this);
    t2.join();
    snake.speed=snake.speed*2;
    if(score>0){
      score--;
    }else{
      score=0;
    }
  }
  if(detox->x == new_x && detox->y == new_y){
    std::thread t3(&HGame::PlaceDetox, this);
    t3.join();
    snake.speed=0.1;
  }
    if(landmine->x == new_x && landmine->y == new_y){
    snake.alive=false;
  }
}

int HGame::GetScore() const { return score; }
int HGame::GetSize() const { return snake.size;}