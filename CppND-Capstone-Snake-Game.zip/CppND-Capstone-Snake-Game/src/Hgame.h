#ifndef HGAME_H
#define HGAME_H

#include <random>
#include "SDL.h"
#include "controller.h"
#include "Hrenderer.h"
#include "snake.h"
#include <memory>
#include <thread>



class HGame{
 public:
  HGame(std::size_t grid_width, std::size_t grid_height);
  void Run(Controller const &controller, HRenderer &renderer,
           std::size_t target_frame_duration);
  
  int GetScore() const;
  int GetSize() const;

private:
  Snake snake;
  //Task1: Make the food project a shared pointer.
  std::shared_ptr<SDL_Point> food; 
  std::shared_ptr<SDL_Point> toxin; 
  std::shared_ptr<SDL_Point> detox; 
  std::shared_ptr<SDL_Point> landmine; 
  
  std::random_device dev;
  std::mt19937 engine;
  std::uniform_int_distribution<int> random_w;
  std::uniform_int_distribution<int> random_h;

  int score{0};
  void UpdateHG();
  void PlaceFood();
  void PlaceToxin();
  void PlaceDetox();
  void PlaceLandmine();
  
};

#endif