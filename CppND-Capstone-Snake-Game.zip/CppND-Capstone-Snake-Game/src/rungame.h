#ifndef RUNGAME_H
#define RUNGAME_H

#include "controller.h"
#include "Hgame.h"
#include "game.h"
#include "Hrenderer.h"
#include "renderer.h"




class Rungame {
  public:


Rungame(std::size_t  kScreenWidth, std::size_t  kScreenHeight, std::size_t  kGridWidth, std::size_t kGridHeight,std::size_t  kMsPerFrame, int  i);
 
    
  void startGame();
  
  private:
   std::size_t screen_width;
   std::size_t screen_height;
   std::size_t grid_width;
   std::size_t grid_height;
   std::size_t k_MsPerFrame;
   int _i;
};


#endif